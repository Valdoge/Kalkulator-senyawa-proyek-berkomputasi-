#NIM/Nama:16025053/Rizky Rivaldo
#Tanggal: 2 Oktober 2025
#Deskripsi: 

x=int(input("Masukkan nilai x:"))
y=int(input("Masukkan nilai y:"))

Poin=(x//1000)
Diskon=(Poin//100)*y*1000

print("Pelanggan tersebut akan mendapatkan sebanyak", Poin, "poin dan diskon sebesar Rp" +str(Diskon))
